Default model conversion base folder for the demo. Please create the relative path to each specific model under this directory. 
