from .height_compression import HeightCompressionTS
# from pcdet.models.backbones_2d.map_to_bev.__init__ import __all__

# # Try register a pcdet model this way. 
# __all__['HeightCompressionTS'] = HeightCompressionTS
